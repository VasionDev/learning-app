import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { HttpClientModule } from "@angular/common/http";

import { AppComponent } from "./app.component";
import { HomeComponent } from "./home/home.component";
import { LoginComponent } from "./login/login.component";
import { OptionsComponent } from "./options/options.component";
import { LessonComponent } from "./lesson/lesson.component";
import { ResourceComponent } from "./resource/resource.component";
import { FormsModule } from "@angular/forms";

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    OptionsComponent,
    LessonComponent,
    ResourceComponent
  ],
  imports: [BrowserModule, FormsModule, HttpClientModule],
  entryComponents: [
    HomeComponent,
    OptionsComponent,
    LoginComponent,
    LessonComponent,
    ResourceComponent
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
