import { WordpressService } from "./../services/wordpress.service";
import { DataService } from "./../services/data.service";
import { Component, OnInit } from "@angular/core";

let IndexArray = [];
let LessonArray = [];

@Component({
  selector: "app-lesson",
  templateUrl: "./lesson.component.html",
  styleUrls: ["./lesson.component.css"]
})
export class LessonComponent implements OnInit {
  indexLesson: any;
  indexPost: any;
  posts: any;
  count = 0;
  completed = false;
  completedLesson: any[] = [];
  completedIndex: any[] = [];

  constructor(private data: DataService, private wp: WordpressService) {}

  ngOnInit() {
    this.data.currentData.subscribe((data: any) => {
      this.posts = data;
    });
    this.data.currentLesson.subscribe((values: any) => {
      this.indexLesson = values.lesson;
      this.indexPost = values.index;
    });
    this.completedTask();
  }

  onClickResource() {
    this.data.nameChange("ResourceComponent");
  }

  onClickComplete(value: boolean) {
    if (value) {
      this.completeChange(this.indexPost, this.indexLesson);
    } else {
      this.completeRemove(this.indexPost, this.indexLesson);
    }
  }

  onClickLeft() {
    this.data.nameChange("HomeComponent");
  }

  completedTask() {
    this.completedLesson = JSON.parse(localStorage.getItem("Lesson"));
    this.completedIndex = JSON.parse(localStorage.getItem("Index"));

    if (this.completedIndex !== null && this.completedLesson !== null) {
      const indexes = [];
      let indexOfArray: number;
      for (
        indexOfArray = 0;
        indexOfArray < this.completedIndex.length;
        indexOfArray++
      ) {
        if (this.completedIndex[indexOfArray] === this.indexPost) {
          indexes.push(indexOfArray);
        }
      }
      let newIndex: number;
      for (newIndex = 0; newIndex < indexes.length; newIndex++) {
        if (this.completedLesson[indexes[newIndex]] === this.indexLesson) {
          this.completed = true;
        }
      }
    }
  }

  completeChange(completedIndex: any, completedLesson: any) {
    LessonArray = JSON.parse(localStorage.getItem("Lesson"));
    IndexArray = JSON.parse(localStorage.getItem("Index"));
    if (LessonArray === null && IndexArray === null) {
      IndexArray = [];
      LessonArray = [];
    }
    IndexArray.push(completedIndex);
    LessonArray.push(completedLesson);
    localStorage.setItem("Lesson", JSON.stringify(LessonArray));
    localStorage.setItem("Index", JSON.stringify(IndexArray));
    const UserId = localStorage.getItem("UserID");
    if (UserId !== null) {
      this.wp
        .saveData({
          userId: UserId,
          indexArray: IndexArray,
          lessonArray: LessonArray
        })
        .subscribe(
          (res: any) => {
            const value = JSON.parse(res);
            if (value.success === true) {
              this.completed = true;
            } else {
              this.completed = false;
            }
          },
          (err: any) => {
            this.completed = false;
          }
        );
    } else {
      this.completed = true;
    }
  }

  completeRemove(removedIndex: any, removedLesson: any) {
    LessonArray = JSON.parse(localStorage.getItem("Lesson"));
    IndexArray = JSON.parse(localStorage.getItem("Index"));
    if (LessonArray === null && IndexArray === null) {
      IndexArray = [];
      LessonArray = [];
    }
    const indexRemoved = IndexArray.indexOf(removedIndex);
    if (indexRemoved > -1) {
      IndexArray.splice(indexRemoved, 1);
    }
    const lessonRemoved = LessonArray.indexOf(removedLesson);
    if (lessonRemoved > -1) {
      LessonArray.splice(lessonRemoved, 1);
    }
    localStorage.setItem("Lesson", JSON.stringify(LessonArray));
    localStorage.setItem("Index", JSON.stringify(IndexArray));
    const UserId = localStorage.getItem("UserID");
    if (UserId !== null) {
      this.wp
        .saveData({
          userId: UserId,
          indexArray: IndexArray,
          lessonArray: LessonArray
        })
        .subscribe(
          (res: any) => {
            const value = JSON.parse(res);
            if (value.success === true) {
              this.completed = false;
            } else {
              this.completed = true;
            }
          },
          (err: any) => {
            this.completed = true;
          }
        );
    } else {
      this.completed = false;
    }
  }
}
