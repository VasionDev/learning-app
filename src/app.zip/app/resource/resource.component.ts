import { DataService } from './../services/data.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resource',
  templateUrl: './resource.component.html',
  styleUrls: ['./resource.component.css']
})
export class ResourceComponent implements OnInit {
  posts: any;
  indexLesson: any;
  indexPost: any;

  constructor(
    private data: DataService
  ) { }

  ngOnInit() {
    this.data.currentData.subscribe((data: any) => {
      this.posts = data;
    });
    this.data.currentLesson.subscribe((values: any) => {
      this.indexLesson = values.lesson;
      this.indexPost = values.index;
    });
  }

  onClickLeft() {
    this.data.nameChange('LessonComponent');
  }

}
